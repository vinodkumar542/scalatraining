package com.dmac.streams;

/**
 * Created by dharshekthvel on 19/8/17.
 */
public class StreamProcessing {

    public static void main(String args[]) {

    }
}
