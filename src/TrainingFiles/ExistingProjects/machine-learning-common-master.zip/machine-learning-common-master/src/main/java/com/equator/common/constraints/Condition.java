package com.equator.common.constraints;

public interface Condition<T> {
	
	public void check(T object);

}
