package com.dmac.ml.knn;

import java.util.ArrayList;
import java.util.List;

public class BayesianClassification {

	public static void main(String[] args) {
		
	

	}
}
