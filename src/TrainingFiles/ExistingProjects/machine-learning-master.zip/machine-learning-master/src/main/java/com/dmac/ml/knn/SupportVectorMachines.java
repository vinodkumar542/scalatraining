package com.dmac.ml.knn;

public class SupportVectorMachines {
	public static void main(String[] args) {
		
	}
}
