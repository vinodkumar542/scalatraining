package com.dmac.core.jdk8;


public class ScalaProgramCall {
	
	
	public static void main(String args[]) {
		//LoginUserValidator luv = new LoginUserValidator();
		//System.out.println(luv.userNameValidation(""));
	}
}
