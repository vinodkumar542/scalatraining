package com.dmac.analytics.scoring;

import com.dmac.analytics.vo.IPROAnalyticsUser;

public class ScoringManager {

	
	public void persistUserScore(IPROAnalyticsUser iPROAnalyticsUser) {
		
	}
	
	public IPROAnalyticsUser retrieveUserScore(IPROAnalyticsUser iPROAnalyticsUser) {
		return null;
	}
}
