package com.dmac.service;

import org.springframework.stereotype.Service;

@Service
public class MachineLearningService {

	/**
	 * 
	 */
	public void invokeDecisionTree() {
		
	}
	
	/**
	 * 
	 */
	public void invokeBayesianClassification() {
		
	}
}
