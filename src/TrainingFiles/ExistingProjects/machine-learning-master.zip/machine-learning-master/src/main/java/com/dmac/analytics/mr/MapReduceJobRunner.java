package com.dmac.analytics.mr;

public class MapReduceJobRunner {

}
