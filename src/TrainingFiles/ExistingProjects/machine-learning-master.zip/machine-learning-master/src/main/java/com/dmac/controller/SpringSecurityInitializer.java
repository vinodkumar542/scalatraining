//package com.dmac.controller;
//
//import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;
//
///**
// * 
// * @author tester
// *
// */
//public class SpringSecurityInitializer extends AbstractSecurityWebApplicationInitializer {
//
//}
