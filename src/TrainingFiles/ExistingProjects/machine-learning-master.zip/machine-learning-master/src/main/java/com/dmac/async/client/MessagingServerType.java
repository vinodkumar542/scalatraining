package com.dmac.async.client;



/**
*
*
* @author <a href="mailto:aravindh.chinnasamy@gmail.com">Aravindh Chinnasamy</a>
* @version %I%, %G%
* @since 1.0
*/
public enum MessagingServerType {
	
	KAFKA,
	RABBITMQ
}
