package com.dmac.ml.knn;

public class KNearestNeighbour {

	public static void main(String[] args) {
		
	}
}
