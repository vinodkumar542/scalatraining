package com.dmac.analytics.storm;

public class QueueingTopology {

}
