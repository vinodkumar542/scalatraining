object HelloWorld {

  def main(args: Array[String]) {
    println("The world is good")
  }
}