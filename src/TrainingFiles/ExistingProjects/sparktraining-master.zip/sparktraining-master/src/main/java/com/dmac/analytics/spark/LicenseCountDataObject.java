package com.dmac.analytics.spark;

public class LicenseCountDataObject {

	private String id = "";
	private String licenseCount = "";
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getLicenseCount() {
		return licenseCount;
	}
	public void setLicenseCount(String licenseCount) {
		this.licenseCount = licenseCount;
	}
	
	
	
	
}
