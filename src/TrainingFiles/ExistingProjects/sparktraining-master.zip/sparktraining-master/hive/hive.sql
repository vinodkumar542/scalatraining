beeline


!connect jdbc:hive2://localhost:10000 username password org.apache.hive.jdbc.HiveDriver

show tables;


!quit