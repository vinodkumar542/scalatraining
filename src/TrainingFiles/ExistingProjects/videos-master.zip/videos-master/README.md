# Video Descriptions

1. roadshow_news.mp4
The video contains news feeds of RSS parsed and written to elastic search and kibana is visualization of the elastic search to a data table. Tech: Kibana (Data Table), Elastic Search, Java, RSS Feed Parsing.

2. roadshow_twitter.mkv
The video contains a Spark streaming hitting twitter and taking twitter feeds and ingesting to elastic search. Kibana visualization with various graphs with a Dashboard is performed on the elastic search index.
Tech: Kibana, Spark Twitter Streaming, Elastic Search, Many visualization graphs on Kibana.

3. Eclipse_Scala_Project_Creation_Scala_Worksheet.mp4
The video shows how to install eclipse and then create a new scala project in Eclipse (Scala-IDE) and creating a base program in Scala and then at last creating a scala worksheet.


