package com.hashthreesixty.common

/**
  * Created by Chinnasamy on 5/3/17.
  */
object HASHCONFIG extends Enumeration {

  type HASHCONFIG                   = Value

  var APP_STREAMING_NAME            = "Hash360StreamingJOB"
  var MASTER_URL                    = "local[*]"



  var KAFKA_BROKER                  = "localhost:9092"

}
