# scalatrainingintellij
Scala Training - IntelliJ 
