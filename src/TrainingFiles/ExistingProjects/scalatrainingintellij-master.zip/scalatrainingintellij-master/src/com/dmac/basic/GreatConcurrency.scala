package com.dmac.basic

object GreatConcurrency extends App {

  
}

