package com.dmac.basic;

/**
 * Created by dharshekthvel on 8/6/17.
 */
public class ExpressionStatementJava {

    public static void main(String args[]) {


        boolean tellMe = false;

        if (100 > 98)
            tellMe = true;
        else
            tellMe = false;


        System.out.println(tellMe);
    }
}
