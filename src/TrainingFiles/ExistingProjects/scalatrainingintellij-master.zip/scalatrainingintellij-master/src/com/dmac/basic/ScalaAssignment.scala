package com.dmac.basic

/**
  * Created by dharshekthvel on 26/6/17.
  */
object ScalaAssignment {

  val contrats = 100

  val contrats_1 = 200 : Int

  val contracts_2 : Int = 300

  val contrats_3 = { 100 }


  var contrats_10 = 100

  var contrats_11= 200 : Int

  var contrats_12: Int = 300


  // Multiple assignments in the same line
  val (name: String, age: Int, salary) = ("Chola", 100, 102f)


}
