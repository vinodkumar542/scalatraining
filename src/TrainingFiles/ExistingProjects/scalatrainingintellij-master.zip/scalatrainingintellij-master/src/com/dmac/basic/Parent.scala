package com.dmac.basic

class Parent extends GrandParent {
  
  val parentName = "_PARENT_"
  
  
}