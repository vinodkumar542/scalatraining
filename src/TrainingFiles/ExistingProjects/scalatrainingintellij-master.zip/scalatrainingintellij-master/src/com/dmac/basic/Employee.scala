package com.dmac.basic

class Employee {


}

case class REDIS(val id : String)