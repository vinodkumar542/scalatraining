package com.dmac.basic

/**
  * Created by dharshekthvel on 8/6/17.
  */
object ExpressionStatement {

  def main(args: Array[String]) = {


    val tellMe = if (100 > 98) true else false


    print(tellMe)
  }


}
