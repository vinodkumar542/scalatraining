package com.dmac.basic

/**
  * Created by dharshekthvel.
  */
object DefiningAMethod {

  def scalaMethod(empName:String, empDepartment : String) : Int = {
    return 1001
  }

}
