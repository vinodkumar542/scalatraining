package com.dmac.kafka;


/**
 * Created by dharshekthvel on 8/6/17.
 */
public class KafkaStreamDMAC {

    public static void main(String args[]) {
//
//        KStreamBuilder streamBuilder = new KStreamBuilder();
//        KStream<String,String> textLines = streamBuilder.stream(Serdes.String(), Serdes.String(), "DACHU");
//
//


    }

}
