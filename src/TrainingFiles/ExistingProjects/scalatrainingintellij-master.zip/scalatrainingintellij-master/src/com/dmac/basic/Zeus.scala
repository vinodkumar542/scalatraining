package com.dmac.basic

class Zeus {
  
  var zeusName = "_ZEUS_"
}