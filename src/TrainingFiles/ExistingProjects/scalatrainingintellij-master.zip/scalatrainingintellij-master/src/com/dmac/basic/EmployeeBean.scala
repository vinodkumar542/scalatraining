package com.dmac.basic

class EmployeeBean {
  
  var empID         = 0;
  
  var empName       = "";
  
  var department    = ""
}