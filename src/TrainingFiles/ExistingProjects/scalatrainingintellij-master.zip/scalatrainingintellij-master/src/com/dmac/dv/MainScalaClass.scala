package com.dmac.dv

/**
  * Created by dharshekthvel on 10/22/16.
  */
object MainScalaClass {

  def main(args : Array[String]) = {
    println("Hello")
  }

}
