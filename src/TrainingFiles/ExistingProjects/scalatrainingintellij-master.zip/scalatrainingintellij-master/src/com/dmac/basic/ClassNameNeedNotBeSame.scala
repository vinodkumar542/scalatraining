package com.dmac.basic

class ADifferentClassNameOtherThanASourceFile {
  
}

class AClassCanHaveMultiplePublicClasses {
  
}