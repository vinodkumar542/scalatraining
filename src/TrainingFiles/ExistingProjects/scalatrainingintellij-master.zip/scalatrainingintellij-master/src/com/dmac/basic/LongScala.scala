package com.dmac.basic

/**
  * Created by dharshekthvel on 20/6/17.
  */
object LongScala extends App {

  println(scala.Long.MaxValue)

}
