package com.dmac.basic

class Child extends Parent {
  
  var childName = "_CHILD_"
  
  var name = "_CHILD_"
}

//class JSONFactory extends XMLFactory {
//  override def readXML(): Unit = {
//
//  }
//}
//
//class XMLFileFactory extends FileFactorys {
//
//  override def getMeFile(): Unit = {
//
//  }
//
//}