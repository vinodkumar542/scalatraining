package com.dmac.basic

/**
  * Created by dharshekthvel on 18/4/17.
  */
class CassandraFactory(factoryName : String) {

  val anInteger = 100
  val sInteger = 100 : Float

  def dataReckoner(data : String) : Int = {
    100
  }
}
