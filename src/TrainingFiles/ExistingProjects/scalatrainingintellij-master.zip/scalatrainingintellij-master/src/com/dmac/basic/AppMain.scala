package com.dmac.basic

object AppMain extends App {
  
  println("The whole block of code is executed when the Object class is extended from the App class")


}