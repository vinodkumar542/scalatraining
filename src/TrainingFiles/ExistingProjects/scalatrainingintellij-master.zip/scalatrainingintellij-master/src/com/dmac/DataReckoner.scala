package com.dmac

/**
  * Created by dharshekthvel on 16/5/17.
  */
class DataReckoner {

  def dataInput(data: String) : Int = {
    12
  }
}
