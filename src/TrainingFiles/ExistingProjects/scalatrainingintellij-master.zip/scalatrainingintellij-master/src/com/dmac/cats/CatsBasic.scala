package com.dmac.cats

/**
  * Created by dharshekthvel on 26/6/17.
  */
object CatsBasic {

  def main(args : Array[String]) = {

//    import cats.Show
//    import cats.std.int._
//    import cats.syntax.show._
//
//    import cats.Eq
//
//
//    import scala.language.higherKinds





  }
}
