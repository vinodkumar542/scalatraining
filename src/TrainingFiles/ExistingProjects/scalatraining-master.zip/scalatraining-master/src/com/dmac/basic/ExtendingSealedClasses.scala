package com.dmac.basic


class ExtendingSealedClasses  { //extends FileFactory {
  
}