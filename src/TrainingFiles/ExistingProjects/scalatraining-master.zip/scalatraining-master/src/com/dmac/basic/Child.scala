package com.dmac.basic

class Child extends Parent {
  
  var childName = "_CHILD_"
  
  var name = "_CHILD_"
}