package com.dmac.spark

object SparkReadFile {
  
  def main(args: Array[String]) : Unit = {
    
    println("Spark Read File")
    
    
    
  }
}