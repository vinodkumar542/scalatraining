package com.dmac.basic

object LoggingInScala {
  
  //val logger = LoggerFactory.getLogger(classOf[Pizza])
  
  def main(arguments : Array[String]) : Unit = {
    
  }
  
}