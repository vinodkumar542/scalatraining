package com.dmac.basic

class Employee {
  
  
  
}