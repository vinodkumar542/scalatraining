package com.dmac.basic

object SealedClasses extends App {
  
}



sealed class FileFactory {
  
}

class XMLFileFactory extends FileFactory {
  
}