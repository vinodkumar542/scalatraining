package com.dmac.basic

import akka.actor.Actor
import akka.actor.ActorSystem
import akka.actor.Props



object GreatThread extends App {
  
  //val actorSystem = ActorSystem.create()
  //val firstLane = actorSystem.actorOf(Props[FirstLane], name = "FirstLane")
  
  
  
  
}

//class FirstLane extends Actor {
//  
//  def receive = {
//  
//    case _ => println("In the First Lane")
//  }
//}