package com.dmac.basic

object ScalaMain {
  
  
  def ScalaMain(i : String): Unit =  {
     println("Constructor")
  }
  
  
  /*
   * Unit - It is a datatype that corresponds to no value
   */
  def main(args: Array[String]): Unit = {
    println("Hello GOD")

    ScalaMain("")
    
  }
}