package any.packagee.name

class ADifferentClassNameOtherThanASourceFile {
  
}

class AClassCanHaveMultiplePublicClasses {
  
}