package com.dmac.basic

class GrandParent extends Zeus {
  
  var grandParentName = "_GRAND_PARENT_"
}